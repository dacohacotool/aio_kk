-Video hướng dẫn, giải thích và setup chrome:https://youtu.be/H_8ZUAp9tAc?si=O82zWg-1ZXUloIwh
-Video hướng dẫn tải và setup python từ a-z. Hướng dẫn chạy tool:https://youtu.be/b_GyOWYxd8c?si=7epSsd_x9HnDCnSG
Cách chạy file:gõ "cmd" ở trên thanh công cụ, sau đó gõ "python main.py"