var API_TOKEN = "apitoken5qqwdthaqvig9fdyv7izphieaijrcrhoqgncu4vg0vmh2cevbftehzafsxlt221724075314";
var DELAY_CLICK = 300;
var LOOP = true;